import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { GeeScriptExecutionParams, GeeScriptType } from "@/types";
import { executeGeeScript, uploadGeeScript } from "@/lib/gee-api";

export const useGeeScripts = () => {
  const [isExecuting, setIsExecuting] = useState(false);
  const [scriptResult, setScriptResult] = useState<any>(null);
  const [executedScriptType, setExecutedScriptType] = useState<GeeScriptType | null>(null);
  const [showResultPanel, setShowResultPanel] = useState(false);
  const { toast } = useToast();

  const executeScript = useCallback(async (params: GeeScriptExecutionParams) => {
    setIsExecuting(true);
    setScriptResult(null);
    setExecutedScriptType(null);
    setShowResultPanel(false);
    
    toast({
      title: "Executing script",
      description: `Running ${params.scriptType} script...`,
    });

    try {
      const response = await executeGeeScript(params);
      
      if (response.status === 'success') {
        toast({
          title: "Script executed successfully",
          description: `${params.scriptType} analysis complete.`,
        });
        
        // Store the result for display
        if (response.data) {
          setScriptResult(response.data);
          setExecutedScriptType(params.scriptType);
          setShowResultPanel(true);
        }
      } else {
        toast({
          title: "Script execution failed",
          description: response.error || "Unknown error occurred",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Script execution error",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsExecuting(false);
    }
  }, [toast]);

  const uploadCustomScript = useCallback(() => {
    // Create a file input element and trigger it
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.js,.ts,.py';
    
    fileInput.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setIsExecuting(true);
        toast({
          title: "Uploading script",
          description: `Uploading ${file.name}...`,
        });
        
        try {
          const result = await uploadGeeScript(file);
          
          if (result.status === 'success') {
            toast({
              title: "Script uploaded successfully",
              description: `${file.name} has been uploaded.`,
            });
          } else {
            toast({
              title: "Upload failed",
              description: result.error || "Unknown error occurred",
              variant: "destructive"
            });
          }
        } catch (error) {
          toast({
            title: "Upload error",
            description: error instanceof Error ? error.message : "Unknown error occurred",
            variant: "destructive"
          });
        } finally {
          setIsExecuting(false);
        }
      }
    };
    
    fileInput.click();
  }, [toast]);

  const closeResultPanel = useCallback(() => {
    setShowResultPanel(false);
  }, []);

  return {
    executeScript,
    uploadCustomScript,
    isExecuting,
    scriptResult,
    executedScriptType,
    showResultPanel,
    closeResultPanel
  };
};
