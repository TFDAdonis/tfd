import { apiRequest } from "./queryClient";

// The models we'll use for different analysis types
const MODELS = {
  default: "anthropic/claude-3-haiku",
  detailed: "anthropic/claude-3-opus",
  vision: "anthropic/claude-3-opus"
};

// Define response interfaces
interface OpenRouterResponse {
  id: string;
  choices: {
    index: number;
    message: {
      role: string;
      content: string;
    };
  }[];
  model: string;
}

export interface AIAnalysisResult {
  summary: string;
  interpretation: string;
  details: string[];
  recommendations: string[];
}

/**
 * Analyze GEE script results using AI via OpenRouter
 */
export async function analyzeResults(scriptType: string, result: any): Promise<AIAnalysisResult> {
  try {
    // Specific prompt engineering based on script type
    let systemPrompt = "";
    let userPrompt = "";
    
    switch(scriptType) {
      case 'calculateEC':
        systemPrompt = "You are an expert in soil salinity analysis. Interpret electrical conductivity (EC) measurements to assess soil salinity levels and provide insights on agricultural implications.";
        userPrompt = `Analyze these EC measurement results from a soil salinity study: ${JSON.stringify(result, null, 2)}. 
        
        In your analysis: 
        1. Explain what these EC values indicate about soil salinity levels
        2. Interpret the implications for agriculture and plant growth
        3. Identify potential risks or concerns based on these measurements
        4. Recommend appropriate management strategies
        
        Format your response as JSON with these fields: 
        {
          "summary": "A brief 1-2 sentence overview of the results", 
          "interpretation": "A paragraph explaining what these values mean",
          "details": ["3-5 bullet points with specific observations"],
          "recommendations": ["3-5 bullet points with practical recommendations"]
        }`;
        break;
        
      case 'estimateSAR':
        systemPrompt = "You are an expert in soil chemistry analyzing Sodium Adsorption Ratio (SAR) data. Provide insights on soil sodicity, structural stability, and management recommendations.";
        userPrompt = `Analyze these SAR results from soil testing: ${JSON.stringify(result, null, 2)}.
        
        In your analysis:
        1. Interpret SAR values and what they indicate about soil sodicity
        2. Explain implications for soil structure and permeability
        3. Assess potential impacts on plant growth and agriculture
        4. Suggest appropriate management strategies
        
        Format your response as JSON with these fields:
        {
          "summary": "A brief 1-2 sentence overview of the results",
          "interpretation": "A paragraph explaining what these SAR values mean",
          "details": ["3-5 bullet points with specific observations"],
          "recommendations": ["3-5 bullet points with practical management recommendations"]
        }`;
        break;
        
      case 'detectSaltAffectedSoils':
        systemPrompt = "You are an expert in detecting and mapping salt-affected soils. Provide insights on the extent and severity of soil salinity based on remote sensing data.";
        userPrompt = `Analyze this salt-affected soil detection data: ${JSON.stringify(result, null, 2)}.
        
        In your analysis:
        1. Interpret the extent and severity of salt-affected areas
        2. Explain patterns or trends in the spatial distribution
        3. Assess the reliability of the detection results
        4. Suggest monitoring and management approaches
        
        Format your response as JSON with these fields:
        {
          "summary": "A brief 1-2 sentence overview of the detection results",
          "interpretation": "A paragraph explaining the patterns and significance",
          "details": ["3-5 bullet points with specific observations"],
          "recommendations": ["3-5 bullet points for monitoring and management"]
        }`;
        break;
        
      case 'analyzeHistoricalTrends':
        systemPrompt = "You are an expert in soil salinity trends analysis. Interpret temporal patterns in soil salinity data to identify long-term changes and provide insights on future projections.";
        userPrompt = `Analyze these historical soil salinity trend data: ${JSON.stringify(result, null, 2)}.
        
        In your analysis:
        1. Identify significant trends or patterns over time
        2. Explain potential causes for observed changes
        3. Assess implications for long-term land management
        4. Suggest strategies for adaptation and mitigation
        
        Format your response as JSON with these fields:
        {
          "summary": "A brief 1-2 sentence overview of the historical trends",
          "interpretation": "A paragraph explaining the significance of these trends",
          "details": ["3-5 bullet points with specific observations"],
          "recommendations": ["3-5 bullet points for adaptation and management"]
        }`;
        break;
        
      default:
        systemPrompt = "You are an expert in soil science analyzing soil data. Provide a comprehensive interpretation of the results and practical recommendations.";
        userPrompt = `Analyze these soil analysis results: ${JSON.stringify(result, null, 2)}.
        
        Format your response as JSON with these fields:
        {
          "summary": "A brief 1-2 sentence overview",
          "interpretation": "A paragraph explaining what these values mean",
          "details": ["3-5 bullet points with specific observations"],
          "recommendations": ["3-5 bullet points with practical recommendations"]
        }`;
    }

    // Call the server endpoint which will proxy to OpenRouter API
    const response = await fetch("/api/ai/analyze", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        system_prompt: systemPrompt,
        user_prompt: userPrompt,
        model: MODELS.default
      })
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    // Parse the AI response content as JSON
    try {
      const responseData = await response.json();
      
      if (!responseData || !responseData.choices || !responseData.choices[0] || !responseData.choices[0].message) {
        throw new Error("Invalid response format from AI service");
      }
      
      const content = responseData.choices[0].message.content;
      const parsedResult = JSON.parse(content) as AIAnalysisResult;
      return parsedResult;
    } catch (e) {
      console.error("Failed to parse AI response:", e);
      // Fallback result if parsing fails
      return {
        summary: "Analysis could not be processed correctly.",
        interpretation: "The AI analysis service returned a response in an unexpected format.",
        details: ["Data was analyzed but results could not be formatted properly."],
        recommendations: ["Try running the analysis again.", "Contact support if the problem persists."]
      };
    }

  } catch (error) {
    console.error("AI analysis error:", error);
    return {
      summary: "Analysis could not be completed.",
      interpretation: "There was an error connecting to the AI analysis service.",
      details: ["The analysis service may be temporarily unavailable."],
      recommendations: ["Try again later.", "Check your network connection."]
    };
  }
}