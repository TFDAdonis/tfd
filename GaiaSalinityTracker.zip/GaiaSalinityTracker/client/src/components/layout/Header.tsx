import { Button } from "@/components/ui/button";

const Header = () => {
  return (
    <header className="bg-white border-b border-neutral-300 shadow-sm py-2 px-4 flex items-center justify-between z-10">
      <div className="flex items-center">
        <div className="flex items-center">
          <div className="text-primary-dark mr-2">
            <span className="material-icons text-3xl">eco</span>
          </div>
          <div>
            <h1 className="font-montserrat font-bold text-xl md:text-2xl text-primary-dark">GaiaDex</h1>
            <p className="text-xs text-neutral-600">by TFDTECK</p>
          </div>
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <Button 
          variant="ghost" 
          className="hidden md:flex items-center text-neutral-700 hover:text-primary px-2 py-1 text-sm"
        >
          <span className="material-icons text-sm mr-1">help_outline</span>
          Help
        </Button>
        <Button 
          variant="ghost" 
          className="hidden md:flex items-center text-neutral-700 hover:text-primary px-2 py-1 text-sm"
        >
          <span className="material-icons text-sm mr-1">settings</span>
          Settings
        </Button>
        <Button 
          className="flex items-center bg-primary text-white px-3 py-1.5 rounded text-sm hover:bg-primary-dark"
        >
          <span className="material-icons text-sm mr-1">account_circle</span>
          Sign In
        </Button>
      </div>
    </header>
  );
};

export default Header;
