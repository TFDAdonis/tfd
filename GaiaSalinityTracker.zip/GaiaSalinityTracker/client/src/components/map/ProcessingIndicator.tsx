const ProcessingIndicator = () => {
  return (
    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white bg-opacity-90 rounded-lg shadow-lg p-4">
      <div className="flex items-center space-x-3">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
        <div>
          <p className="font-medium text-neutral-800">Processing Analysis</p>
          <p className="text-sm text-neutral-600">Calculating soil salinity...</p>
        </div>
      </div>
    </div>
  );
};

export default ProcessingIndicator;
