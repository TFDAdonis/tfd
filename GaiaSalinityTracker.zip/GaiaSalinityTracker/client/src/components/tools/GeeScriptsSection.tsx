import { Button } from "@/components/ui/button";
import { useGeeScripts } from "@/hooks/useGeeScripts";
import { GeeScriptType } from "@/types";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import ScriptResultPanel from "@/components/analysis/ScriptResultPanel";
import { Dialog, DialogContent } from "@/components/ui/dialog";

const scriptDetails = {
  calculateEC: {
    title: "Calculate EC from Sentinel-2",
    description: "Calculates soil Electrical Conductivity using Sentinel-2 imagery.",
    badge: "🛰️ Sentinel-2",
    details: "Uses NIR and SWIR bands to estimate soil salinity in the Algeria test region."
  },
  estimateSAR: {
    title: "Estimate SAR from Landsat",
    description: "Estimates Sodium Adsorption Ratio using Landsat imagery.",
    badge: "🛰️ Landsat",
    details: "Analyzes spectral signatures to determine SAR levels in soil."
  },
  detectSaltAffectedSoils: {
    title: "Detect Salt-Affected Soils",
    description: "Maps areas affected by soil salinity.",
    badge: "🗺️ Mapping",
    details: "Uses multi-spectral imagery to identify salt-affected areas in the test region."
  },
  analyzeHistoricalTrends: {
    title: "Analyze Historical Trends",
    description: "Analyzes salinity changes over time (2014-2024).",
    badge: "📈 Time Series",
    details: "Correlates precipitation and salinity data to identify long-term trends.",
    featured: true
  }
};

const GeeScriptsSection = () => {
  const { 
    executeScript, 
    uploadCustomScript, 
    isExecuting, 
    scriptResult, 
    executedScriptType, 
    showResultPanel, 
    closeResultPanel 
  } = useGeeScripts();

  const handleExecuteScript = (scriptType: GeeScriptType) => {
    executeScript({ 
      scriptType,
      region: {
        type: "Polygon",
        coordinates: [[
          [-0.5461, 35.0111],
          [-0.4771, 35.0111],
          [-0.4771, 35.0294],
          [-0.5461, 35.0294],
          [-0.5461, 35.0111]
        ]]
      },
      startDate: "2014-01-01",
      endDate: "2024-12-31"
    });
  };

  const handleUploadCustomScript = () => {
    uploadCustomScript();
  };

  return (
    <div className="bg-neutral-100 rounded-lg p-3">
      <h3 className="font-semibold text-neutral-800 mb-2">Google Earth Engine Scripts</h3>
      <p className="text-sm text-neutral-600 mb-3">Analyze soil salinity with these GEE scripts.</p>
      
      <div className="space-y-3">
        {/* Featured script - Historical Trends Analysis */}
        <Card className="border-primary/20 bg-white/80">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-sm font-medium">
                {scriptDetails.analyzeHistoricalTrends.title}
              </CardTitle>
              <Badge variant="outline" className="bg-primary/10 text-primary text-xs">
                {scriptDetails.analyzeHistoricalTrends.badge}
              </Badge>
            </div>
            <CardDescription className="text-xs">
              {scriptDetails.analyzeHistoricalTrends.description}
            </CardDescription>
          </CardHeader>
          <CardFooter className="pt-0">
            <Button
              variant="default"
              size="sm"
              disabled={isExecuting}
              onClick={() => handleExecuteScript('analyzeHistoricalTrends')}
              className="w-full flex items-center justify-center"
            >
              <span className="material-icons text-sm mr-1">play_circle</span>
              Run Analysis
            </Button>
          </CardFooter>
        </Card>
        
        {/* Other scripts */}
        <Accordion type="single" collapsible className="bg-white rounded-md border overflow-hidden">
          <AccordionItem value="item-1">
            <AccordionTrigger className="px-3 py-2 text-sm hover:no-underline">
              <div className="flex items-center">
                <span className="material-icons text-sm mr-2 text-primary">insights</span>
                <span>Calculate Soil Salinity Metrics</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-3 pb-3">
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={isExecuting}
                  onClick={() => handleExecuteScript('calculateEC')}
                  className="w-full flex items-center justify-between"
                >
                  <span>{scriptDetails.calculateEC.title}</span>
                  <span className="material-icons text-sm">play_arrow</span>
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  disabled={isExecuting}
                  onClick={() => handleExecuteScript('estimateSAR')}
                  className="w-full flex items-center justify-between"
                >
                  <span>{scriptDetails.estimateSAR.title}</span>
                  <span className="material-icons text-sm">play_arrow</span>
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  disabled={isExecuting}
                  onClick={() => handleExecuteScript('detectSaltAffectedSoils')}
                  className="w-full flex items-center justify-between"
                >
                  <span>{scriptDetails.detectSaltAffectedSoils.title}</span>
                  <span className="material-icons text-sm">play_arrow</span>
                </Button>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
      
      <div className="mt-3">
        <Button
          variant="secondary"
          disabled={isExecuting}
          onClick={handleUploadCustomScript}
          className="w-full flex items-center justify-center text-sm"
        >
          <span className="material-icons text-sm mr-1">upload_file</span>
          Upload Custom Script
        </Button>
      </div>

      {/* Result Dialog */}
      <Dialog open={showResultPanel} onOpenChange={(open) => !open && closeResultPanel()}>
        <DialogContent 
          className="sm:max-w-md p-0 border-none bg-transparent shadow-none"
          aria-labelledby="dialog-title"
          aria-describedby="dialog-description"
        >
          {showResultPanel && executedScriptType && scriptResult && (
            <ScriptResultPanel 
              scriptType={executedScriptType}
              result={scriptResult}
              onClose={closeResultPanel}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GeeScriptsSection;
