import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const geeScripts = pgTable("gee_scripts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  scriptType: text("script_type").notNull(),
  code: text("code").notNull(),
  createdById: integer("created_by_id").references(() => users.id),
  isPublic: boolean("is_public").default(false),
  parameters: jsonb("parameters"),
  createdAt: text("created_at").notNull()
});

export const analysisResults = pgTable("analysis_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  scriptId: integer("script_id").references(() => geeScripts.id),
  parameters: jsonb("parameters").notNull(),
  results: jsonb("results").notNull(),
  status: text("status").notNull(),
  region: jsonb("region"),
  createdAt: text("created_at").notNull()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGeeScriptSchema = createInsertSchema(geeScripts).pick({
  name: true,
  description: true,
  scriptType: true,
  code: true,
  createdById: true,
  isPublic: true,
  parameters: true,
});

export const insertAnalysisResultSchema = createInsertSchema(analysisResults).pick({
  userId: true,
  scriptId: true,
  parameters: true,
  results: true,
  status: true,
  region: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGeeScript = z.infer<typeof insertGeeScriptSchema>;
export type GeeScript = typeof geeScripts.$inferSelect;

export type InsertAnalysisResult = z.infer<typeof insertAnalysisResultSchema>;
export type AnalysisResult = typeof analysisResults.$inferSelect;
