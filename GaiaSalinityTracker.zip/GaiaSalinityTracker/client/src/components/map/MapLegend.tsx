import { useMapState } from "@/hooks/useMapState";

const MapLegend = () => {
  const { mapState } = useMapState();
  
  // Only show legend when salinity layer is active
  if (!mapState.visibleLayers.includes('salinity')) return null;

  return (
    <div className="absolute bottom-4 right-4 bg-white rounded-md shadow-md p-3 max-w-xs">
      <h4 className="font-montserrat font-semibold text-sm text-neutral-800 mb-2">Soil Salinity (EC, dS/m)</h4>
      <div className="bg-gradient-to-r from-[#009688] via-[#CDDC39] to-[#F44336] h-3 rounded-sm mb-2"></div>
      <div className="flex justify-between text-xs text-neutral-600">
        <span>0</span>
        <span>2</span>
        <span>4</span>
        <span>8</span>
        <span>16+</span>
      </div>
      <div className="flex justify-between text-xs font-medium mt-1">
        <span className="text-success">Non-saline</span>
        <span className="text-warning">Moderate</span>
        <span className="text-danger">Severe</span>
      </div>
    </div>
  );
};

export default MapLegend;
