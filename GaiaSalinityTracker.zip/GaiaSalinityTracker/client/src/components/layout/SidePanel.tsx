import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AnalysisSection from "@/components/tools/AnalysisSection";
import GeeScriptsSection from "@/components/tools/GeeScriptsSection";
import DataLayersSection from "@/components/tools/DataLayersSection";
import { useAnalysis } from "@/hooks/useAnalysis";

const SidePanel = () => {
  const [activeTab, setActiveTab] = useState("analysis");
  const [activeToolTab, setActiveToolTab] = useState("soil");
  const { runAnalysis, isAnalysisRunning } = useAnalysis();

  const handleRunAnalysis = () => {
    runAnalysis();
  };

  return (
    <>
      <div className="flex border-b border-neutral-300">
        <Button
          variant={activeTab === "analysis" ? "default" : "ghost"}
          className={`flex-1 py-3 px-4 text-center font-medium ${
            activeTab === "analysis" 
              ? "text-primary border-b-2 border-primary" 
              : "text-neutral-600 hover:text-primary"
          }`}
          onClick={() => setActiveTab("analysis")}
        >
          Analysis Tools
        </Button>
        <Button
          variant={activeTab === "results" ? "default" : "ghost"}
          className={`flex-1 py-3 px-4 text-center font-medium ${
            activeTab === "results" 
              ? "text-primary border-b-2 border-primary" 
              : "text-neutral-600 hover:text-primary"
          }`}
          onClick={() => setActiveTab("results")}
        >
          Results
        </Button>
      </div>

      {activeTab === "analysis" && (
        <>
          <div className="flex border-b border-neutral-300 bg-neutral-100">
            <Button
              variant={activeToolTab === "soil" ? "default" : "ghost"}
              className={`flex-1 py-2 px-2 text-center text-sm font-medium ${
                activeToolTab === "soil" 
                  ? "text-primary border-b-2 border-primary" 
                  : "text-neutral-600 hover:text-primary"
              }`}
              onClick={() => setActiveToolTab("soil")}
            >
              Soil Analysis
            </Button>
            <Button
              variant={activeToolTab === "vegetation" ? "default" : "ghost"}
              className={`flex-1 py-2 px-2 text-center text-sm font-medium ${
                activeToolTab === "vegetation" 
                  ? "text-primary border-b-2 border-primary" 
                  : "text-neutral-600 hover:text-primary"
              }`}
              onClick={() => setActiveToolTab("vegetation")}
            >
              Vegetation
            </Button>
            <Button
              variant={activeToolTab === "climate" ? "default" : "ghost"}
              className={`flex-1 py-2 px-2 text-center text-sm font-medium ${
                activeToolTab === "climate" 
                  ? "text-primary border-b-2 border-primary" 
                  : "text-neutral-600 hover:text-primary"
              }`}
              onClick={() => setActiveToolTab("climate")}
            >
              Climate
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto data-panel p-4 space-y-4">
            {activeToolTab === "soil" && (
              <>
                <AnalysisSection />
                <GeeScriptsSection />
                <DataLayersSection />
                
                <div className="bg-neutral-100 rounded-lg p-3">
                  <Button
                    onClick={handleRunAnalysis}
                    disabled={isAnalysisRunning}
                    className="w-full flex items-center justify-center bg-primary text-white rounded-md px-4 py-2 font-medium hover:bg-primary-dark transition-colors"
                  >
                    <span className="material-icons mr-1">analytics</span>
                    {isAnalysisRunning ? "Running..." : "Run Analysis"}
                  </Button>
                </div>
              </>
            )}
            
            {activeToolTab === "vegetation" && (
              <div className="p-4 text-center text-neutral-500">
                Vegetation analysis tools coming soon
              </div>
            )}
            
            {activeToolTab === "climate" && (
              <div className="p-4 text-center text-neutral-500">
                Climate analysis tools coming soon
              </div>
            )}
          </div>
        </>
      )}

      {activeTab === "results" && (
        <div className="flex-1 overflow-y-auto data-panel p-4">
          <div className="p-4 text-center text-neutral-500">
            Run an analysis to see results here
          </div>
        </div>
      )}
    </>
  );
};

export default SidePanel;
