import { Switch, Route, Link } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/Header";
import SidePanel from "@/components/layout/SidePanel";
import MapContainer from "@/components/layout/MapContainer";
import OlMapPage from "@/pages/OlMapPage";
import { useState } from "react";
import { Button } from "@/components/ui/button";

function HomePage() {
  const [isMobilePanelOpen, setIsMobilePanelOpen] = useState(false);

  const toggleMobilePanel = () => {
    setIsMobilePanelOpen(!isMobilePanelOpen);
  };

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex flex-col md:flex-row flex-1 h-full overflow-hidden">
        <div 
          className={`${isMobilePanelOpen ? 'h-1/2 md:h-auto' : 'h-auto md:h-auto'} 
                     w-full md:w-80 bg-white border-r border-neutral-300 flex flex-col z-10 
                     overflow-hidden transition-all duration-300 md:static 
                     ${isMobilePanelOpen ? 'absolute bottom-0 left-0 right-0' : 'md:relative'}`}
        >
          <SidePanel />
        </div>
        <MapContainer 
          toggleMobilePanel={toggleMobilePanel} 
          isMobilePanelOpen={isMobilePanelOpen} 
        />
      </div>
    </div>
  );
}

function MapSwitcher() {
  return (
    <div className="fixed top-16 right-4 z-50 flex gap-2">
      <Link href="/">
        <Button variant="outline" className="shadow-md bg-white">
          Leaflet Map
        </Button>
      </Link>
      <Link href="/openlayers">
        <Button variant="outline" className="shadow-md bg-white">
          OpenLayers Map
        </Button>
      </Link>
    </div>
  );
}

function Router() {
  return (
    <>
      <MapSwitcher />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/openlayers" component={OlMapPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
