import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useMapState } from "@/hooks/useMapState";
import { LayerType } from "@/types";

const DataLayersSection = () => {
  const { mapState, setMapState } = useMapState();

  const handleLayerToggle = (layer: LayerType) => {
    const updatedLayers = mapState.visibleLayers.includes(layer)
      ? mapState.visibleLayers.filter(l => l !== layer)
      : [...mapState.visibleLayers, layer];
    
    setMapState({
      ...mapState,
      visibleLayers: updatedLayers
    });
  };

  return (
    <div className="bg-neutral-100 rounded-lg p-3">
      <h3 className="font-montserrat font-semibold text-neutral-800 mb-2">Map Data Layers</h3>
      <p className="text-sm text-neutral-600 mb-3">Enable or disable map visualization layers.</p>
      
      <div className="space-y-2">
        <div className="flex items-center">
          <Checkbox 
            id="layer-salinity" 
            checked={mapState.visibleLayers.includes('salinity')}
            onCheckedChange={() => handleLayerToggle('salinity')}
            className="mr-2" 
          />
          <Label htmlFor="layer-salinity" className="text-sm text-neutral-700 flex-1">Soil Salinity</Label>
          <div className="w-16 h-3 bg-gradient-to-r from-[#009688] via-[#CDDC39] to-[#F44336] rounded-sm"></div>
        </div>
        
        <div className="flex items-center">
          <Checkbox 
            id="layer-moisture" 
            checked={mapState.visibleLayers.includes('moisture')}
            onCheckedChange={() => handleLayerToggle('moisture')}
            className="mr-2" 
          />
          <Label htmlFor="layer-moisture" className="text-sm text-neutral-700 flex-1">Soil Moisture</Label>
          <div className="w-16 h-3 bg-gradient-to-r from-neutral-100 to-secondary rounded-sm"></div>
        </div>
        
        <div className="flex items-center">
          <Checkbox 
            id="layer-elevation" 
            checked={mapState.visibleLayers.includes('elevation')}
            onCheckedChange={() => handleLayerToggle('elevation')}
            className="mr-2" 
          />
          <Label htmlFor="layer-elevation" className="text-sm text-neutral-700 flex-1">Elevation</Label>
          <div className="w-16 h-3 bg-gradient-to-r from-[#795548] via-[#D7CCC8] to-[#607D8B] rounded-sm"></div>
        </div>
        
        <div className="flex items-center">
          <Checkbox 
            id="layer-landcover" 
            checked={mapState.visibleLayers.includes('landcover')}
            onCheckedChange={() => handleLayerToggle('landcover')}
            className="mr-2" 
          />
          <Label htmlFor="layer-landcover" className="text-sm text-neutral-700 flex-1">Land Cover</Label>
          <div className="w-16 h-3 bg-gradient-to-r from-primary-light via-accent to-danger rounded-sm"></div>
        </div>
        
        <div className="flex items-center">
          <Checkbox 
            id="layer-precipitation" 
            checked={mapState.visibleLayers.includes('precipitation')}
            onCheckedChange={() => handleLayerToggle('precipitation')}
            className="mr-2" 
          />
          <Label htmlFor="layer-precipitation" className="text-sm text-neutral-700 flex-1">Precipitation</Label>
          <div className="w-16 h-3 bg-gradient-to-r from-white via-blue-200 to-blue-500 rounded-sm"></div>
        </div>
      </div>
    </div>
  );
};

export default DataLayersSection;
