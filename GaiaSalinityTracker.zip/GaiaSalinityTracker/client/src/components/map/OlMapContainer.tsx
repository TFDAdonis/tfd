import React, { useEffect, useRef, useState } from 'react';
import 'ol/ol.css';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';
import XYZ from 'ol/source/XYZ';
import { fromLonLat, toLonLat } from 'ol/proj';
import { defaults as defaultControls } from 'ol/control';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import Feature from 'ol/Feature';
import Polygon from 'ol/geom/Polygon';
import { Fill, Stroke, Style } from 'ol/style';
import { defaults as defaultInteractions } from 'ol/interaction';
import { Button } from "@/components/ui/button";
import { useMapState } from "@/hooks/useMapState";
import { MapState, Location, LayerType } from '@/types';
import { Loader2, Search, ZoomIn, ZoomOut, Map as MapIcon, Layers } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Algeria region of interest coordinates [longitude, latitude]
const ALGERIA_ROI = [
  [-0.5461, 35.0111],
  [-0.4771, 35.0111],
  [-0.4771, 35.0294],
  [-0.5461, 35.0294],
  [-0.5461, 35.0111]
];

// Sample locations for search
const LOCATIONS: Location[] = [
  { name: "Algeria Test Site", coordinates: [35.0203, -0.5116] },
  { name: "Central Valley, California", coordinates: [36.7783, -119.4179] },
  { name: "Colorado River Delta", coordinates: [32.0889, -114.9661] },
  { name: "Aral Sea, Kazakhstan", coordinates: [45.0, 60.0] },
  { name: "Murray-Darling Basin", coordinates: [-34.5, 144.0] },
  { name: "Nile Delta, Egypt", coordinates: [30.8, 31.2] }
];

interface OlMapContainerProps {
  toggleMobilePanel?: () => void;
  isMobilePanelOpen?: boolean;
}

const OlMapContainer = ({ toggleMobilePanel, isMobilePanelOpen }: OlMapContainerProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<Map | null>(null);
  const [isMapLoading, setIsMapLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Location[]>([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const { mapState, setMapState, zoomIn, zoomOut } = useMapState();

  // Initialize map
  useEffect(() => {
    if (!mapRef.current || map) return;

    // Convert Algeria ROI coordinates to OpenLayers format
    const roiCoords = ALGERIA_ROI.map(coord => fromLonLat(coord));

    // Create vector layer for ROI polygon
    const roiSource = new VectorSource({
      features: [
        new Feature({
          geometry: new Polygon([roiCoords])
        })
      ]
    });

    const roiLayer = new VectorLayer({
      source: roiSource,
      style: new Style({
        fill: new Fill({
          color: 'rgba(255, 0, 50, 0.2)'
        }),
        stroke: new Stroke({
          color: 'rgba(255, 0, 0, 0.8)',
          width: 2
        })
      })
    });

    // Create base tile layer
    const osmLayer = new TileLayer({
      source: new OSM(),
      zIndex: 0
    });

    // Create satellite layer
    const satelliteLayer = new TileLayer({
      source: new XYZ({
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attributions: 'Powered by Esri'
      }),
      visible: false,
      zIndex: 1
    });

    // Create terrain layer
    const terrainLayer = new TileLayer({
      source: new XYZ({
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer/tile/{z}/{y}/{x}',
        attributions: 'Powered by Esri'
      }),
      visible: false,
      zIndex: 2
    });

    // Create OpenLayers map
    const olMap = new Map({
      target: mapRef.current,
      layers: [osmLayer, satelliteLayer, terrainLayer, roiLayer],
      controls: defaultControls({ zoom: false, rotate: false }),
      interactions: defaultInteractions({ doubleClickZoom: false }),
      view: new View({
        center: fromLonLat([mapState.center[1], mapState.center[0]]), // OpenLayers uses [lon, lat]
        zoom: mapState.zoom,
        maxZoom: 19
      })
    });

    // Save layers to map object for easy access
    olMap.set('osmLayer', osmLayer);
    olMap.set('satelliteLayer', satelliteLayer);
    olMap.set('terrainLayer', terrainLayer);
    olMap.set('roiLayer', roiLayer);

    setMap(olMap);
    setIsMapLoading(false);

    // Map move end event
    olMap.on('moveend', () => {
      const view = olMap.getView();
      const center = view.getCenter();
      if (center) {
        const lonLat = toLonLat(center);
        setMapState({
          ...mapState,
          center: [lonLat[1], lonLat[0]], // Convert to [lat, lon] format for state
          zoom: view.getZoom() || mapState.zoom
        });
      }
    });

    // Cleanup
    return () => {
      if (olMap) {
        olMap.setTarget(undefined);
      }
    };
  }, []);

  // Handle map updates when mapState changes
  useEffect(() => {
    if (!map) return;

    const view = map.getView();
    const currentCenter = view.getCenter();
    if (!currentCenter) return;

    const currentLonLat = toLonLat(currentCenter);
    const targetLonLat = [mapState.center[1], mapState.center[0]]; // Convert from [lat, lon] to [lon, lat]

    // Only update if the position has changed significantly
    if (
      Math.abs(currentLonLat[0] - targetLonLat[0]) > 0.0001 ||
      Math.abs(currentLonLat[1] - targetLonLat[1]) > 0.0001 ||
      view.getZoom() !== mapState.zoom
    ) {
      view.animate({
        center: fromLonLat(targetLonLat),
        zoom: mapState.zoom,
        duration: 500
      });
    }
  }, [mapState.center, mapState.zoom]);

  // Update visible layers
  useEffect(() => {
    if (!map) return;

    // Toggle satellite layer
    const satelliteLayer = map.get('satelliteLayer');
    const osmLayer = map.get('osmLayer');
    const terrainLayer = map.get('terrainLayer');

    if (mapState.visibleLayers.includes('satellite')) {
      satelliteLayer.setVisible(true);
      osmLayer.setVisible(false);
      terrainLayer.setVisible(false);
    } else if (mapState.visibleLayers.includes('terrain')) {
      satelliteLayer.setVisible(false);
      osmLayer.setVisible(false);
      terrainLayer.setVisible(true);
    } else {
      satelliteLayer.setVisible(false);
      osmLayer.setVisible(true);
      terrainLayer.setVisible(false);
    }

  }, [map, mapState.visibleLayers]);

  // Handle search functionality
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setSearchResults([]);
      return;
    }

    const filteredLocations = LOCATIONS.filter(
      location => location.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setSearchResults(filteredLocations);
    setShowSearchResults(true);
  }, [searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchResults.length > 0) {
      handleSelectLocation(searchResults[0]);
    }
  };

  const handleSelectLocation = (location: Location) => {
    setMapState({
      ...mapState,
      center: location.coordinates,
      zoom: 10
    });
    setSearchQuery(location.name);
    setShowSearchResults(false);
  };

  const toggleLayer = (layer: LayerType) => {
    const currentLayers = [...mapState.visibleLayers];
    const index = currentLayers.indexOf(layer);
    
    if (index === -1) {
      // If it's 'satellite' or 'terrain', remove the other view layers first
      if (layer === 'satellite' || layer === 'terrain') {
        const layersToRemove: LayerType[] = ['satellite', 'terrain'];
        layersToRemove.forEach(l => {
          const idx = currentLayers.indexOf(l);
          if (idx !== -1) {
            currentLayers.splice(idx, 1);
          }
        });
      }
      currentLayers.push(layer);
    } else {
      currentLayers.splice(index, 1);
    }
    
    setMapState({
      ...mapState,
      visibleLayers: currentLayers
    });
  };

  return (
    <div className="flex-1 relative">
      <div 
        ref={mapRef} 
        className="w-full h-full"
        style={{ cursor: isMapLoading ? 'wait' : 'grab' }}
      >
        {isMapLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-70 z-50">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}
      </div>

      {/* Search control */}
      <div className="absolute top-4 left-4 w-64 z-10">
        <form onSubmit={handleSearch}>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search location..."
              className="pr-10 shadow-md"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit" 
              size="icon" 
              variant="ghost" 
              className="absolute right-0 top-0 h-full"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </form>

        {/* Search results */}
        {showSearchResults && searchResults.length > 0 && (
          <Card className="mt-1 p-1 shadow-md max-h-48 overflow-y-auto">
            <div className="space-y-0.5">
              {searchResults.map((location, index) => (
                <div
                  key={index}
                  className="flex items-center px-2 py-1.5 hover:bg-neutral-100 rounded cursor-pointer text-sm"
                  onClick={() => handleSelectLocation(location)}
                >
                  <MapIcon className="h-3.5 w-3.5 mr-2 text-neutral-500" />
                  {location.name}
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>

      {/* Map controls */}
      <div className="absolute top-4 right-4 flex flex-col space-y-2">
        <Button 
          size="icon" 
          variant="outline" 
          className="bg-white shadow-md h-8 w-8"
          onClick={zoomIn}
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button 
          size="icon" 
          variant="outline" 
          className="bg-white shadow-md h-8 w-8"
          onClick={zoomOut}
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
      </div>

      {/* Layer controls */}
      <div className="absolute bottom-16 right-4 flex flex-col space-y-2">
        <Button
          size="sm"
          variant={mapState.visibleLayers.includes('satellite') ? "default" : "outline"}
          className={`shadow-md ${mapState.visibleLayers.includes('satellite') ? 'bg-primary' : 'bg-white'}`}
          onClick={() => toggleLayer('satellite')}
        >
          <Layers className="h-4 w-4 mr-1" />
          Satellite
        </Button>
        <Button
          size="sm"
          variant={mapState.visibleLayers.includes('terrain') ? "default" : "outline"}
          className={`shadow-md ${mapState.visibleLayers.includes('terrain') ? 'bg-primary' : 'bg-white'}`}
          onClick={() => toggleLayer('terrain')}
        >
          <Layers className="h-4 w-4 mr-1" />
          Terrain
        </Button>
        <Button
          size="sm"
          variant={mapState.visibleLayers.includes('salinity') ? "default" : "outline"}
          className={`shadow-md ${mapState.visibleLayers.includes('salinity') ? 'bg-primary' : 'bg-white'}`}
          onClick={() => toggleLayer('salinity')}
        >
          <Layers className="h-4 w-4 mr-1" />
          Salinity
        </Button>
      </div>

      {/* Region badge */}
      <div className="absolute bottom-4 left-4">
        <Badge variant="secondary" className="bg-white/90 shadow-md py-1.5">
          <MapIcon className="h-3.5 w-3.5 mr-1.5" />
          Algeria Test Region
        </Badge>
      </div>

      {/* Mobile panel toggle (if provided) */}
      {toggleMobilePanel && (
        <div className="md:hidden absolute bottom-0 left-0 right-0 bg-white border-t border-neutral-300 p-2 flex justify-center">
          <Button 
            variant="ghost" 
            className="flex items-center text-neutral-700 text-sm font-medium"
            onClick={toggleMobilePanel}
          >
            <span className="material-icons text-sm mr-1">
              {isMobilePanelOpen ? 'expand_more' : 'expand_less'}
            </span>
            Analysis Tools
          </Button>
        </div>
      )}
    </div>
  );
};

export default OlMapContainer;