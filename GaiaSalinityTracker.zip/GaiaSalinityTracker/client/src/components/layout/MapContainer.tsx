import { useEffect, useRef, useState } from "react";
import MapControls from "@/components/map/MapControls";
import MapLegend from "@/components/map/MapLegend";
import AnalysisInfoPanel from "@/components/map/AnalysisInfoPanel";
import SearchLocation from "@/components/map/SearchLocation";
import ProcessingIndicator from "@/components/map/ProcessingIndicator";
import { useMapState } from "@/hooks/useMapState";
import { useAnalysis } from "@/hooks/useAnalysis";
import L from "leaflet";
import { Button } from "@/components/ui/button";

// Fix for Leaflet icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

interface MapContainerProps {
  toggleMobilePanel: () => void;
  isMobilePanelOpen: boolean;
}

// Algeria region of interest from GEE script
const ALGERIA_ROI: [number, number][] = [
  [35.0111, -0.5461],
  [35.0111, -0.4771],
  [35.0294, -0.4771],
  [35.0294, -0.5461],
  [35.0111, -0.5461]
];

const MapContainer = ({ toggleMobilePanel, isMobilePanelOpen }: MapContainerProps) => {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const { mapState, setMapState } = useMapState();
  const { isAnalysisRunning, analysisResult } = useAnalysis();
  const [roiPolygon, setRoiPolygon] = useState<L.Polygon | null>(null);

  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      // Fix Leaflet's default icon
      const DefaultIcon = L.icon({
        iconUrl: icon,
        shadowUrl: iconShadow,
        iconSize: [25, 41],
        iconAnchor: [12, 41]
      });
      L.Marker.prototype.options.icon = DefaultIcon;
      
      // Initialize map
      mapRef.current = L.map(mapContainerRef.current, {
        center: [35.0203, -0.5116], // Centered on Algeria ROI
        zoom: 12,
        zoomControl: false
      });

      // Add tile layer (base map)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(mapRef.current);

      // Add Algeria ROI polygon
      const latlngs = ALGERIA_ROI.map(coord => L.latLng(coord[0], coord[1]));
      const polygon = L.polygon(latlngs, {
        color: 'red',
        weight: 2,
        fillColor: '#f03',
        fillOpacity: 0.2
      }).addTo(mapRef.current);
      
      polygon.bindPopup("Region of Interest: Algeria Test Site");
      setRoiPolygon(polygon);

      // Handle map move events
      mapRef.current.on('moveend', () => {
        if (mapRef.current) {
          const center = mapRef.current.getCenter();
          setMapState({
            ...mapState,
            center: [center.lat, center.lng],
            zoom: mapRef.current.getZoom()
          });
        }
      });

      // Clean up on unmount
      return () => {
        if (mapRef.current) {
          mapRef.current.remove();
          mapRef.current = null;
        }
      };
    }
  }, []);

  // Update map when center or zoom changes in mapState
  useEffect(() => {
    if (mapRef.current) {
      const currentCenter = mapRef.current.getCenter();
      const currentZoom = mapRef.current.getZoom();
      
      // Only update if the values are actually different to avoid loops
      if (currentCenter.lat !== mapState.center[0] || 
          currentCenter.lng !== mapState.center[1] ||
          currentZoom !== mapState.zoom) {
        console.log('Updating map position to:', mapState.center, mapState.zoom);
        mapRef.current.setView(mapState.center, mapState.zoom, { animate: true });
      }
    }
  }, [mapState.center, mapState.zoom]);

  // Update map when visible layers change
  useEffect(() => {
    if (mapRef.current) {
      // Example of adding a salinity layer overlay
      if (mapState.visibleLayers.includes('salinity')) {
        // In a real implementation, this would load a GEE-generated layer
        if (roiPolygon) {
          roiPolygon.setStyle({
            fillColor: '#f03',
            fillOpacity: 0.4,
            color: 'red'
          });
        }
      } else {
        if (roiPolygon) {
          roiPolygon.setStyle({
            fillColor: '#f03',
            fillOpacity: 0.2,
            color: 'red'
          });
        }
      }
    }
  }, [mapState.visibleLayers, roiPolygon]);

  return (
    <div className="flex-1 relative overflow-hidden">
      <div 
        ref={mapContainerRef} 
        className="map-container w-full h-full bg-neutral-200"
      ></div>

      <MapControls />
      <MapLegend />
      {analysisResult && <AnalysisInfoPanel result={analysisResult} />}
      <SearchLocation />
      {isAnalysisRunning && <ProcessingIndicator />}
      
      <div className="md:hidden absolute bottom-0 left-0 right-0 bg-white border-t border-neutral-300 p-2 flex justify-center">
        <Button 
          variant="ghost" 
          className="flex items-center text-neutral-700 text-sm font-medium"
          onClick={toggleMobilePanel}
        >
          <span className="material-icons text-sm mr-1">
            {isMobilePanelOpen ? 'expand_more' : 'expand_less'}
          </span>
          Analysis Tools
        </Button>
      </div>
    </div>
  );
};

export default MapContainer;
