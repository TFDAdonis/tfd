// Map related types
export interface MapState {
  center: [number, number];
  zoom: number;
  selectedArea?: SelectedArea;
  visibleLayers: LayerType[];
}

export interface SelectedArea {
  name: string;
  coordinates: [number, number][];
}

export type LayerType = 'salinity' | 'moisture' | 'elevation' | 'landcover' | 'precipitation' | 'satellite' | 'terrain';

// Analysis related types
export interface AnalysisParams {
  analysisType: 'EC' | 'SAR' | 'ESP';
  depthRangeStart: number;
  depthRangeEnd: number;
  timePeriod: string;
}

export interface AnalysisResult {
  selectedArea: string;
  averageSalinity: number;
  affectedArea: number;
  confidenceLevel: number;
}

// GEE Script related types
export type GeeScriptType = 
  | 'calculateEC' 
  | 'estimateSAR' 
  | 'detectSaltAffectedSoils' 
  | 'analyzeHistoricalTrends';

export interface GeeScriptExecutionParams {
  scriptType: GeeScriptType;
  region?: any; // GeoJSON
  startDate?: string;
  endDate?: string;
  additionalParams?: Record<string, any>;
}

export interface GeeScriptExecutionResult {
  status: 'success' | 'error';
  data?: any;
  error?: string;
}

// Location related types
export interface Location {
  name: string;
  coordinates: [number, number];
}
