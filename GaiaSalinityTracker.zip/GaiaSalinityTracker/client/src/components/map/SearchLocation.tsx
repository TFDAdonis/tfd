import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useMapState } from "@/hooks/useMapState";
import { Location } from "@/types";

const LOCATIONS: Location[] = [
  { name: "Algeria Test Site", coordinates: [35.0203, -0.5116] },
  { name: "Central Valley, California", coordinates: [36.7783, -119.4179] },
  { name: "Colorado River Delta", coordinates: [32.0889, -114.9661] },
  { name: "Aral Sea, Kazakhstan", coordinates: [45.0, 60.0] }
];

const SearchLocation = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isRecentExpanded, setIsRecentExpanded] = useState(true);
  const [filteredLocations, setFilteredLocations] = useState<Location[]>(LOCATIONS.slice(0, 2));
  const { goToLocation } = useMapState();

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredLocations(LOCATIONS.slice(0, 2)); // Show only 2 locations when empty
      return;
    }
    
    const filtered = LOCATIONS.filter(location => 
      location.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredLocations(filtered);
  }, [searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Find exact location match if possible
    const exactMatch = LOCATIONS.find(
      loc => loc.name.toLowerCase() === searchQuery.toLowerCase()
    );
    
    if (exactMatch) {
      goToLocation(exactMatch);
    } else if (filteredLocations.length > 0) {
      // Go to first filtered result
      goToLocation(filteredLocations[0]);
    }
    
    console.log("Searching for:", searchQuery);
  };

  const handleLocationSelect = (location: Location) => {
    setSearchQuery(location.name);
    goToLocation(location);
  };

  return (
    <div className="absolute top-4 left-4 md:left-4 w-64 z-10">
      <div className="bg-white rounded-md shadow-md">
        <form onSubmit={handleSearch} className="relative">
          <Input 
            type="text" 
            placeholder="Search location..." 
            className="w-full px-3 py-2 pl-10 rounded-md border-0 text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button 
            type="submit"
            variant="ghost" 
            size="icon" 
            className="absolute left-1 top-1/2 transform -translate-y-1/2 h-7 w-7"
          >
            <span className="material-icons text-sm text-neutral-400">search</span>
          </Button>
        </form>
      </div>
      
      {filteredLocations.length > 0 && (
        <div className="mt-2 bg-white rounded-md shadow-md p-2">
          <div 
            className="flex justify-between items-center mb-1 cursor-pointer"
            onClick={() => setIsRecentExpanded(!isRecentExpanded)}
          >
            <span className="text-xs font-medium text-neutral-600">
              {searchQuery ? "Search Results" : "Recent Locations"}
            </span>
            <span className="material-icons text-xs text-neutral-500">
              {isRecentExpanded ? 'expand_less' : 'expand_more'}
            </span>
          </div>
          
          {isRecentExpanded && (
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {filteredLocations.map((location, index) => (
                <div 
                  key={index}
                  className="flex items-center px-1 py-1 hover:bg-neutral-100 rounded cursor-pointer"
                  onClick={() => handleLocationSelect(location)}
                >
                  <span className="material-icons text-sm text-neutral-500 mr-1">location_on</span>
                  <span className="text-xs">{location.name}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchLocation;
