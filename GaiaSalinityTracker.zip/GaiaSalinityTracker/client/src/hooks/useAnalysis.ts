import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { AnalysisParams, AnalysisResult } from "@/types";
import { apiRequest } from "@/lib/queryClient";

// Initial analysis parameters
const initialAnalysisParams: AnalysisParams = {
  analysisType: 'EC',
  depthRangeStart: 0,
  depthRangeEnd: 30,
  timePeriod: 'last-12-months'
};

export const useAnalysis = () => {
  const [analysisParams, setAnalysisParams] = useState<AnalysisParams>(initialAnalysisParams);
  const [isAnalysisRunning, setIsAnalysisRunning] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const { toast } = useToast();

  const runAnalysis = useCallback(async () => {
    setIsAnalysisRunning(true);
    toast({
      title: "Starting Analysis",
      description: `Analyzing soil salinity using ${analysisParams.analysisType}...`,
    });

    try {
      // In a real app, this would call the API
      // Simulate API call with a timeout
      setTimeout(() => {
        // Sample result data (in a real app this would come from the API)
        const result: AnalysisResult = {
          selectedArea: "San Joaquin Valley, CA",
          averageSalinity: 5.7,
          affectedArea: 467.3,
          confidenceLevel: 82
        };
        
        setAnalysisResult(result);
        setIsAnalysisRunning(false);
        
        toast({
          title: "Analysis Complete",
          description: "Soil salinity analysis has been completed successfully.",
        });
      }, 3000);
    } catch (error) {
      setIsAnalysisRunning(false);
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to complete analysis",
        variant: "destructive"
      });
    }
  }, [analysisParams, toast]);

  return {
    analysisParams,
    setAnalysisParams,
    runAnalysis,
    isAnalysisRunning,
    analysisResult
  };
};
