import React from 'react';
import { AIAnalysisResult } from '@/lib/ai-analysis';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Check, Lightbulb, FileBarChart, ListChecks } from 'lucide-react';
import { GeeScriptType } from '@/types';

interface AIAnalysisPanelProps {
  scriptType: GeeScriptType;
  analysis: AIAnalysisResult;
}

const AIAnalysisPanel = ({ scriptType, analysis }: AIAnalysisPanelProps) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          AI Analysis
        </span>
        <span className="text-xs bg-gradient-to-r from-blue-600 to-purple-600 px-2 py-0.5 rounded-full text-white font-normal">
          Expert
        </span>
      </h3>

      <Alert className="bg-blue-50/50 border-blue-200">
        <Lightbulb className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800 font-medium">Summary</AlertTitle>
        <AlertDescription className="text-blue-700">
          {analysis.summary}
        </AlertDescription>
      </Alert>

      <div className="text-sm text-gray-700 leading-relaxed">
        {analysis.interpretation}
      </div>

      <Tabs defaultValue="details" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="details" className="text-xs">
            <FileBarChart className="h-3 w-3 mr-1" />
            Details
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="text-xs">
            <ListChecks className="h-3 w-3 mr-1" />
            Recommendations
          </TabsTrigger>
        </TabsList>
        <TabsContent value="details" className="space-y-2 pt-2">
          <ul className="space-y-1">
            {analysis.details.map((detail, index) => (
              <li key={index} className="text-xs text-gray-600 flex">
                <span className="text-blue-500 mr-1.5 flex-shrink-0">•</span>
                <span>{detail}</span>
              </li>
            ))}
          </ul>
        </TabsContent>
        <TabsContent value="recommendations" className="space-y-2 pt-2">
          <ul className="space-y-2">
            {analysis.recommendations.map((recommendation, index) => (
              <li key={index} className="text-xs text-gray-700 flex items-start">
                <Check className="h-3 w-3 text-green-500 mr-1.5 mt-0.5 flex-shrink-0" />
                <span>{recommendation}</span>
              </li>
            ))}
          </ul>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AIAnalysisPanel;