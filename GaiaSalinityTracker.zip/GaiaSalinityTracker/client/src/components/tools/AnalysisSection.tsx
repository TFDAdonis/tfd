import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAnalysis } from "@/hooks/useAnalysis";
import { AnalysisParams } from "@/types";

const AnalysisSection = () => {
  const { setAnalysisParams, analysisParams } = useAnalysis();

  const handleAnalysisTypeChange = (value: string) => {
    setAnalysisParams({
      ...analysisParams,
      analysisType: value as AnalysisParams['analysisType']
    });
  };

  const handleDepthRangeStartChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAnalysisParams({
      ...analysisParams,
      depthRangeStart: parseInt(e.target.value) || 0
    });
  };

  const handleDepthRangeEndChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAnalysisParams({
      ...analysisParams,
      depthRangeEnd: parseInt(e.target.value) || 30
    });
  };

  const handleTimePeriodChange = (value: string) => {
    setAnalysisParams({
      ...analysisParams,
      timePeriod: value
    });
  };

  return (
    <div className="bg-neutral-100 rounded-lg p-3">
      <h3 className="font-montserrat font-semibold text-neutral-800 mb-2">Soil Salinity Analysis</h3>
      <p className="text-sm text-neutral-600 mb-3">Calculate and visualize soil salinity levels based on selected parameters.</p>
      
      <div className="space-y-3">
        <div>
          <Label className="block text-sm font-medium text-neutral-700 mb-1">Analysis Type</Label>
          <Select 
            value={analysisParams.analysisType} 
            onValueChange={handleAnalysisTypeChange}
          >
            <SelectTrigger className="w-full px-3 py-2 border border-neutral-300 rounded-md text-sm">
              <SelectValue placeholder="Select analysis type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="EC">EC (Electrical Conductivity)</SelectItem>
              <SelectItem value="SAR">SAR (Sodium Adsorption Ratio)</SelectItem>
              <SelectItem value="ESP">ESP (Exchangeable Sodium Percentage)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label className="block text-sm font-medium text-neutral-700 mb-1">Depth Range</Label>
          <div className="flex items-center space-x-2">
            <Input 
              type="number" 
              placeholder="0" 
              className="w-1/2 px-3 py-2 border border-neutral-300 rounded-md text-sm"
              value={analysisParams.depthRangeStart}
              onChange={handleDepthRangeStartChange}
            />
            <span className="text-neutral-500">to</span>
            <Input 
              type="number" 
              placeholder="30" 
              className="w-1/2 px-3 py-2 border border-neutral-300 rounded-md text-sm"
              value={analysisParams.depthRangeEnd}
              onChange={handleDepthRangeEndChange}
            />
            <span className="text-neutral-500">cm</span>
          </div>
        </div>
        
        <div>
          <Label className="block text-sm font-medium text-neutral-700 mb-1">Time Period</Label>
          <Select 
            value={analysisParams.timePeriod} 
            onValueChange={handleTimePeriodChange}
          >
            <SelectTrigger className="w-full px-3 py-2 border border-neutral-300 rounded-md text-sm">
              <SelectValue placeholder="Select time period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last-12-months">Last 12 months</SelectItem>
              <SelectItem value="last-5-years">Last 5 years</SelectItem>
              <SelectItem value="2010-2020">2010-2020</SelectItem>
              <SelectItem value="custom">Custom range</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};

export default AnalysisSection;
