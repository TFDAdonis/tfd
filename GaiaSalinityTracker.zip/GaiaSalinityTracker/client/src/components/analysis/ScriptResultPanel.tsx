import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GeeScriptType } from '@/types';
import { Button } from '@/components/ui/button';
import { Separator } from "@/components/ui/separator";
import { analyzeResults, AIAnalysisResult } from '@/lib/ai-analysis';
import AIAnalysisPanel from './AIAnalysisPanel';
import { Loader2 } from 'lucide-react';

interface ScriptResultPanelProps {
  scriptType: GeeScriptType;
  result: any;
  onClose: () => void;
}

const scriptInfo = {
  calculateEC: {
    title: "Electrical Conductivity (EC)",
    description: "Measures the amount of salts in soil (dS/m)",
    badge: "Sentinel-2",
    color: "bg-blue-100 text-blue-800"
  },
  estimateSAR: {
    title: "Sodium Adsorption Ratio (SAR)",
    description: "Indicates sodium hazard in soil",
    badge: "Landsat",
    color: "bg-orange-100 text-orange-800"
  },
  detectSaltAffectedSoils: {
    title: "Salt-Affected Soils",
    description: "Areas affected by soil salinity",
    badge: "Multi-spectral",
    color: "bg-red-100 text-red-800"
  },
  analyzeHistoricalTrends: {
    title: "Historical Salinity Trends",
    description: "Salinity changes over time (2014-2024)",
    badge: "Time Series",
    color: "bg-purple-100 text-purple-800"
  }
};

const ScriptResultPanel = ({ scriptType, result, onClose }: ScriptResultPanelProps) => {
  const info = scriptInfo[scriptType];
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(true);

  // Generate AI analysis
  useEffect(() => {
    const runAnalysis = async () => {
      setIsAnalyzing(true);
      try {
        const analysis = await analyzeResults(scriptType, result);
        setAiAnalysis(analysis);
      } catch (error) {
        console.error('Error running AI analysis:', error);
      } finally {
        setIsAnalyzing(false);
      }
    };

    runAnalysis();
  }, [scriptType, result]);

  const renderContent = () => {
    switch (scriptType) {
      case 'calculateEC':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Average EC:</div>
              <div className="text-xl font-bold">{result.avg_ec} dS/m</div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">EC Values Distribution:</div>
              <div className="flex items-end h-32 space-x-1">
                {result.ec_values.map((value: number, index: number) => (
                  <div 
                    key={index}
                    className="bg-blue-500 rounded-t"
                    style={{ 
                      height: `${(value / Math.max(...result.ec_values)) * 100}%`,
                      width: `${100 / result.ec_values.length - 2}%`
                    }}
                  >
                    <div className="mt-2 text-xs rotate-90 origin-bottom-left whitespace-nowrap">
                      {value.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-xs text-neutral-500 mt-1">
                Values above 4.0 dS/m indicate saline soil conditions
              </div>
            </div>
          </div>
        );
      
      case 'estimateSAR':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Average SAR:</div>
              <div className="text-xl font-bold">{result.avg_sar}</div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">SAR Values Distribution:</div>
              <div className="flex items-end h-32 space-x-1">
                {result.sar_values.map((value: number, index: number) => (
                  <div 
                    key={index}
                    className="bg-orange-500 rounded-t"
                    style={{ 
                      height: `${(value / Math.max(...result.sar_values)) * 100}%`,
                      width: `${100 / result.sar_values.length - 2}%`
                    }}
                  >
                    <div className="mt-2 text-xs rotate-90 origin-bottom-left whitespace-nowrap">
                      {value.toFixed(1)}
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-xs text-neutral-500 mt-1">
                SAR values above 13 indicate sodium hazard
              </div>
            </div>
          </div>
        );
      
      case 'detectSaltAffectedSoils':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Affected Area:</div>
              <div className="text-xl font-bold">{result.affected_area} ha</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Percentage Affected:</div>
              <div className="text-xl font-bold">{result.percentage_affected}%</div>
            </div>
            
            <div className="space-y-2">
              <div className="text-sm font-medium">Severity Levels:</div>
              <div className="relative pt-1">
                <div className="flex h-4 overflow-hidden text-xs rounded">
                  <div 
                    className="bg-red-600 text-white flex items-center justify-center"
                    style={{ width: `${result.severity_levels.severe}%` }}
                  >
                    {result.severity_levels.severe > 10 ? `${Math.round(result.severity_levels.severe)}%` : ''}
                  </div>
                  <div 
                    className="bg-orange-500 text-white flex items-center justify-center"
                    style={{ width: `${result.severity_levels.moderate}%` }}
                  >
                    {result.severity_levels.moderate > 10 ? `${Math.round(result.severity_levels.moderate)}%` : ''}
                  </div>
                  <div 
                    className="bg-yellow-400 text-white flex items-center justify-center"
                    style={{ width: `${result.severity_levels.mild}%` }}
                  >
                    {result.severity_levels.mild > 10 ? `${Math.round(result.severity_levels.mild)}%` : ''}
                  </div>
                </div>
              </div>
              <div className="flex text-xs justify-between">
                <span className="text-red-600">Severe</span>
                <span className="text-orange-500">Moderate</span>
                <span className="text-yellow-500">Mild</span>
              </div>
            </div>
          </div>
        );
      
      case 'analyzeHistoricalTrends':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Trend Correlation:</div>
              <div className="text-xl font-bold">{result.correlation.toFixed(2)}</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Annual Salinity Change:</div>
              <div className="text-xl font-bold">
                {result.trend_slope > 0 ? '+' : ''}{result.trend_slope.toFixed(3)} per year
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-sm font-medium">Time Series (2014-2024):</div>
              <div className="h-40 relative border rounded p-2">
                <div className="absolute inset-0 flex flex-col justify-between py-2 px-4">
                  <div className="border-b border-gray-200 w-full"></div>
                  <div className="border-b border-gray-200 w-full"></div>
                  <div className="border-b border-gray-200 w-full"></div>
                  <div className="border-b border-gray-200 w-full"></div>
                </div>
                
                {/* Salinity Line */}
                <div className="relative h-full">
                  <svg className="absolute inset-0 h-full w-full overflow-visible">
                    <polyline
                      points={result.time_series.years.map((year: number, i: number) => {
                        const x = (i / (result.time_series.years.length - 1)) * 100;
                        const minSalinity = Math.min(...result.time_series.salinity);
                        const maxSalinity = Math.max(...result.time_series.salinity);
                        const range = maxSalinity - minSalinity;
                        const normalizedY = 100 - ((result.time_series.salinity[i] - minSalinity) / (range || 1)) * 80;
                        return `${x}% ${normalizedY}%`;
                      }).join(' ')}
                      stroke="#ef4444"
                      strokeWidth="2"
                      fill="none"
                    />
                  </svg>
                  
                  {/* Precipitation Bars */}
                  <div className="flex justify-between items-end absolute bottom-0 inset-x-0 h-20">
                    {result.time_series.precipitation.map((value: number, i: number) => {
                      const maxPrecip = Math.max(...result.time_series.precipitation);
                      const height = (value / maxPrecip) * 100;
                      return (
                        <div key={i} className="flex flex-col items-center" style={{ width: `${100 / result.time_series.precipitation.length}%` }}>
                          <div 
                            className="w-2/3 bg-blue-400 opacity-60 rounded-t"
                            style={{ height: `${height}%` }}
                          ></div>
                          {i % 2 === 0 && (
                            <div className="text-xs mt-1 text-gray-600">
                              {result.time_series.years[i]}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              <div className="flex justify-between text-xs">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div>
                  <span>Salinity Index</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-400 rounded-sm opacity-60 mr-1"></div>
                  <span>Precipitation (mm)</span>
                </div>
              </div>
            </div>
            <div className="text-xs text-neutral-600">
              Negative correlation (-{Math.abs(result.correlation).toFixed(2)}) indicates that increased precipitation is associated with decreased soil salinity.
            </div>
          </div>
        );
      
      default:
        return (
          <div className="py-8 text-center text-neutral-500">
            No result data available
          </div>
        );
    }
  };

  return (
    <div className="pt-4">
      <Card className="w-full max-w-md shadow-lg mx-auto">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-medium" id="dialog-title">
              {info.title}
            </CardTitle>
            <Badge className={info.color}>
              {info.badge}
            </Badge>
          </div>
          <CardDescription id="dialog-description">
            {info.description}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {renderContent()}
          
          {/* AI Analysis Section */}
          {scriptType && (
            <>
              <Separator className="my-4" />
              {isAnalyzing ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
                  <span className="text-sm text-neutral-600">Analyzing results...</span>
                </div>
              ) : (
                aiAnalysis && <AIAnalysisPanel scriptType={scriptType} analysis={aiAnalysis} />
              )}
            </>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-between border-t pt-4">
          <div className="text-xs text-neutral-500">
            {result.region} • {new Date(result.timestamp).toLocaleDateString()}
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            Close
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ScriptResultPanel;