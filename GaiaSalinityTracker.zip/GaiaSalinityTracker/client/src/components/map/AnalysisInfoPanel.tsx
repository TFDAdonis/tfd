import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { type AnalysisResult } from "@/types";

interface AnalysisInfoPanelProps {
  result: AnalysisResult;
}

const AnalysisInfoPanel = ({ result }: AnalysisInfoPanelProps) => {
  return (
    <div className="absolute top-4 right-16 w-64 z-10">
      <Card className="shadow-lg border-none">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            Soil Salinity Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="pb-2">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-neutral-600">Area:</span>
              <span className="font-medium">{result.selectedArea}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Avg. Salinity:</span>
              <span className="font-medium">{result.averageSalinity} dS/m</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Affected Area:</span>
              <span className="font-medium">{result.affectedArea} km²</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Confidence:</span>
              <span className="font-medium">{result.confidenceLevel}%</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="pt-0 flex gap-2">
          <Button variant="outline" size="sm" className="text-xs flex-1">
            Download
          </Button>
          <Button variant="outline" size="sm" className="text-xs flex-1">
            Share
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AnalysisInfoPanel;