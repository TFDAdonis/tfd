import { GeeScriptExecutionParams, GeeScriptExecutionResult } from "@/types";
import { apiRequest } from "./queryClient";

/**
 * Executes a Google Earth Engine script
 */
export async function executeGeeScript(params: GeeScriptExecutionParams): Promise<GeeScriptExecutionResult> {
  try {
    // Make an actual API request to the backend
    const response = await fetch('/api/gee/execute', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to execute script');
    }
    
    const data = await response.json();
    return data as GeeScriptExecutionResult;
  } catch (error) {
    return {
      status: 'error',
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

/**
 * Uploads a custom Google Earth Engine script
 */
export async function uploadGeeScript(scriptFile: File): Promise<GeeScriptExecutionResult> {
  try {
    // This would be implemented with actual file upload logic
    const formData = new FormData();
    formData.append('script', scriptFile);
    
    // Make API request with FormData
    const response = await fetch('/api/scripts/upload', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to upload script');
    }
    
    const data = await response.json();
    return {
      status: 'success',
      data
    };
  } catch (error) {
    return {
      status: 'error',
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

/**
 * Fetches salinity and precipitation time series data
 */
export async function getSalinityPrecipitationData() {
  try {
    const response = await fetch('/api/data/salinity-precipitation');
    if (!response.ok) {
      throw new Error('Failed to fetch salinity-precipitation data');
    }
    return await response.json();
  } catch (error) {
    throw new Error(error instanceof Error ? error.message : 'Failed to fetch salinity-precipitation data');
  }
}

/**
 * Fetches annual salinity index data
 */
export async function getSalinityIndexData() {
  try {
    const response = await fetch('/api/data/salinity-index');
    if (!response.ok) {
      throw new Error('Failed to fetch salinity index data');
    }
    return await response.json();
  } catch (error) {
    throw new Error(error instanceof Error ? error.message : 'Failed to fetch salinity index data');
  }
}
