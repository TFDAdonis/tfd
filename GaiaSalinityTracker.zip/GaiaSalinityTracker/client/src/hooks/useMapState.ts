import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { MapState, LayerType, Location } from "@/types";

// Initial map state centered on world view
const initialMapState: MapState = {
  center: [20, 0],
  zoom: 2,
  visibleLayers: ['salinity'],
};

export const useMapState = () => {
  const [mapState, setMapState] = useState<MapState>(initialMapState);
  const { toast } = useToast();

  const zoomIn = useCallback(() => {
    setMapState(prev => ({
      ...prev,
      zoom: Math.min(prev.zoom + 1, 18)
    }));
  }, []);

  const zoomOut = useCallback(() => {
    setMapState(prev => ({
      ...prev,
      zoom: Math.max(prev.zoom - 1, 1)
    }));
  }, []);

  const goToMyLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setMapState(prev => ({
            ...prev,
            center: [position.coords.latitude, position.coords.longitude],
            zoom: 10
          }));
        },
        (error) => {
          toast({
            title: "Error getting location",
            description: error.message,
            variant: "destructive"
          });
        }
      );
    } else {
      toast({
        title: "Geolocation not supported",
        description: "Your browser does not support geolocation",
        variant: "destructive"
      });
    }
  }, [toast]);

  const goToLocation = useCallback((location: Location) => {
    setMapState(prev => ({
      ...prev,
      center: location.coordinates,
      zoom: 10
    }));
  }, []);

  const toggleMeasureTool = useCallback(() => {
    toast({
      title: "Measure Tool",
      description: "Measurement tool functionality coming soon",
    });
  }, [toast]);

  const toggleLayersPanel = useCallback(() => {
    toast({
      title: "Layers Panel",
      description: "Additional layers panel coming soon",
    });
  }, [toast]);

  return {
    mapState,
    setMapState,
    zoomIn,
    zoomOut,
    goToMyLocation,
    goToLocation,
    toggleMeasureTool,
    toggleLayersPanel
  };
};
