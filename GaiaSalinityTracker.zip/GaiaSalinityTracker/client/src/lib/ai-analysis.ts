import { GeeScriptType } from "@/types";

// Expert knowledge base for soil salinity analysis
const EXPERT_KNOWLEDGE = {
  calculateEC: {
    interpretation: (data: any) => {
      const avgEC = data.avg_ec;
      let severity = 'non-saline';
      let impactLevel = 'minimal';
      let recommendation = '';
      
      // Determine severity based on EC values
      if (avgEC < 2) {
        severity = 'non-saline';
        impactLevel = 'minimal';
        recommendation = 'No specific management for salinity is needed, but regular soil monitoring is recommended.';
      } else if (avgEC >= 2 && avgEC < 4) {
        severity = 'slightly saline';
        impactLevel = 'mild';
        recommendation = 'Select salt-tolerant crops and apply good quality irrigation water. Consider applying organic matter to improve soil structure.';
      } else if (avgEC >= 4 && avgEC < 8) {
        severity = 'moderately saline';
        impactLevel = 'significant';
        recommendation = 'Implement leaching practices to flush salts below root zone. Use salt-tolerant crops and drip irrigation. Consider applying gypsum as a soil amendment.';
      } else if (avgEC >= 8 && avgEC < 16) {
        severity = 'strongly saline';
        impactLevel = 'severe';
        recommendation = 'Only salt-tolerant crops will yield satisfactorily. Implement subsurface drainage and leaching. Apply soil amendments like gypsum and organic matter.';
      } else {
        severity = 'extremely saline';
        impactLevel = 'very severe';
        recommendation = 'Only a few highly salt-tolerant crops will grow. Major reclamation efforts needed, including subsurface drainage, extensive leaching, and soil amendments.';
      }
      
      return {
        summary: `The average Electrical Conductivity (EC) value of ${avgEC.toFixed(2)} dS/m indicates ${severity} soil conditions.`,
        interpretation: `At this level, crops will experience ${impactLevel} impact on growth and yield.`,
        details: [
          `EC values above 4.0 dS/m generally indicate saline soil conditions that can affect plant growth.`,
          `Most sensitive crops show yield reductions starting at EC levels of 2-3 dS/m.`,
          `Moderately tolerant crops can withstand EC levels up to 6 dS/m.`,
          `Highly tolerant crops (like barley, cotton, date palm) can tolerate EC levels up to 10 dS/m.`
        ],
        recommendations: [
          recommendation,
          'Regularly monitor soil salinity through soil testing.',
          'Improve irrigation practices to prevent salt buildup.'
        ]
      };
    }
  },
  
  estimateSAR: {
    interpretation: (data: any) => {
      const avgSAR = data.avg_sar;
      let risk = 'low';
      let recommendation = '';
      
      // Determine risk based on SAR values
      if (avgSAR < 6) {
        risk = 'low';
        recommendation = 'No specific sodium management is needed, but regular soil monitoring is recommended.';
      } else if (avgSAR >= 6 && avgSAR < 10) {
        risk = 'medium';
        recommendation = 'Apply calcium amendments like gypsum to counter sodium effects. Improve soil structure with organic matter.';
      } else if (avgSAR >= 10 && avgSAR < 15) {
        risk = 'high';
        recommendation = 'Apply calcium amendments (gypsum) and organic matter. Improve drainage and implement leaching practices.';
      } else {
        risk = 'very high';
        recommendation = 'Extensive reclamation needed with high rates of calcium amendments, deep tillage, and improved drainage.';
      }
      
      return {
        summary: `The average Sodium Adsorption Ratio (SAR) value of ${avgSAR.toFixed(2)} indicates a ${risk} risk of sodium-related soil problems.`,
        interpretation: `SAR is a measure of the sodium hazard in irrigation water and soil. It affects soil structure and water infiltration.`,
        details: [
          `SAR values above 13 generally indicate a high sodium hazard that can cause soil structure degradation.`,
          `High sodium causes clay particles to disperse, reducing soil permeability and water infiltration.`,
          `Sodium-affected soils typically become hard and compacted when dry and have poor water infiltration when wet.`,
          `Reclamation of high-sodium soils requires calcium sources to replace sodium on soil exchange sites.`
        ],
        recommendations: [
          recommendation,
          'If irrigation water is high in sodium, consider adding calcium sources to the water.',
          'Improve soil drainage to facilitate leaching of sodium from the root zone.'
        ]
      };
    }
  },
  
  detectSaltAffectedSoils: {
    interpretation: (data: any) => {
      const affectedArea = data.affected_area;
      const percentageAffected = data.percentage_affected;
      const severeLevels = data.severity_levels;
      
      // Calculate weighted score based on severity levels
      const weightedScore = 
        (severeLevels.severe * 3 + 
        severeLevels.moderate * 2 + 
        severeLevels.mild * 1) / 100;
      
      let urgency = 'low';
      if (weightedScore < 1) urgency = 'low';
      else if (weightedScore < 1.5) urgency = 'moderate';
      else if (weightedScore < 2) urgency = 'high';
      else urgency = 'very high';
      
      return {
        summary: `${affectedArea.toFixed(1)} hectares (${percentageAffected.toFixed(1)}% of the study area) show salt-affected soil conditions.`,
        interpretation: `The distribution of severity levels indicates a ${urgency} urgency for intervention.`,
        details: [
          `Severe salt-affected areas (${severeLevels.severe.toFixed(1)}%) will have significant crop yield reductions without remediation.`,
          `Moderately affected areas (${severeLevels.moderate.toFixed(1)}%) will show visible stress symptoms in sensitive crops.`,
          `Mildly affected areas (${severeLevels.mild.toFixed(1)}%) may show subtle signs of stress in sensitive crops.`,
          `Salt-affected areas often expand over time if not properly managed.`
        ],
        recommendations: [
          'Prioritize reclamation efforts in severely affected areas.',
          'Implement site-specific management practices based on salinity severity levels.',
          'Install proper drainage systems in affected areas to prevent salt accumulation.',
          'Consider precision agriculture techniques to address spatial variability in salt concentration.'
        ]
      };
    }
  },
  
  analyzeHistoricalTrends: {
    interpretation: (data: any) => {
      const correlation = data.correlation;
      const trendSlope = data.trend_slope;
      
      const correlationStrength = Math.abs(correlation) < 0.3 ? 'weak' : 
                                  Math.abs(correlation) < 0.6 ? 'moderate' : 'strong';
      
      const correlationDirection = correlation < 0 ? 'negative' : 'positive';
      
      const trendDirection = trendSlope > 0 ? 'increasing' : 'decreasing';
      const trendRate = Math.abs(trendSlope) < 0.01 ? 'slow' : 
                        Math.abs(trendSlope) < 0.03 ? 'moderate' : 'rapid';
      
      return {
        summary: `Soil salinity shows an overall ${trendDirection} trend at a ${trendRate} rate (${trendSlope > 0 ? '+' : ''}${trendSlope.toFixed(3)} per year).`,
        interpretation: `There is a ${correlationStrength} ${correlationDirection} correlation (${correlation.toFixed(2)}) between precipitation and soil salinity.`,
        details: [
          `${correlationDirection === 'negative' ? 'Higher precipitation is associated with lower salinity levels, indicating rainfall helps leach salts from the soil.' : 'Higher precipitation is associated with higher salinity levels, which may indicate salts are being transported into the area with rainfall.'}`,
          `The ${trendDirection} trend in salinity over time suggests ${trendDirection === 'increasing' ? 'a gradual salt accumulation that could worsen over time.' : 'natural or managed processes are reducing salt content over time.'}`,
          `Year-to-year variations in salinity correspond with precipitation patterns, showing how climate affects soil salt dynamics.`,
          `Long-term monitoring is essential to distinguish between seasonal fluctuations and permanent changes in soil salinity.`
        ],
        recommendations: [
          `${trendDirection === 'increasing' ? 'Implement preventative measures to slow or reverse the increasing salinity trend.' : 'Continue practices that are contributing to the positive trend of decreasing salinity.'}`,
          'Develop water management strategies that account for precipitation patterns and their effect on soil salinity.',
          'Consider climate forecasts in agricultural planning to anticipate salinity changes.',
          'Establish permanent monitoring points for long-term tracking of salinity trends.'
        ]
      };
    }
  }
};

export interface AIAnalysisResult {
  summary: string;
  interpretation: string;
  details: string[];
  recommendations: string[];
}

/**
 * Analyze GEE script results using AI
 * 
 * This function supports two methods of analysis:
 * 1. Local expert system (uses predefined rules-based analysis)
 * 2. OpenRouter AI (uses advanced AI models for more detailed analysis)
 */
export async function analyzeResults(scriptType: GeeScriptType, result: any): Promise<AIAnalysisResult> {
  // First attempt to use OpenRouter AI for advanced analysis
  try {
    // Import OpenRouter client dynamically to avoid import issues
    const { analyzeResults: analyzeWithAI } = await import('./openrouter-client');
    
    // Call the AI-powered analysis
    const aiAnalysis = await analyzeWithAI(scriptType, result);
    console.log('AI analysis completed successfully');
    return aiAnalysis;
    
  } catch (aiError) {
    console.warn('AI analysis failed, falling back to local expert system:', aiError);
    
    // If OpenRouter fails, fall back to our local expert system
    try {
      // Get the appropriate expert interpretation function
      const interpreter = EXPERT_KNOWLEDGE[scriptType]?.interpretation;
      
      if (!interpreter) {
        throw new Error(`No interpreter available for script type: ${scriptType}`);
      }
      
      // Run the local interpretation
      return interpreter(result);
    } catch (error) {
      console.error('Error analyzing results:', error);
      return {
        summary: 'Unable to analyze results.',
        interpretation: 'An error occurred during analysis.',
        details: ['The analysis engine encountered a problem processing the data.'],
        recommendations: ['Try running the analysis again with different parameters.']
      };
    }
  }
}