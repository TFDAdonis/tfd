import { useState } from "react";
import Header from "@/components/layout/Header";
import SidePanel from "@/components/layout/SidePanel";
import OlMapContainer from "@/components/map/OlMapContainer";

export default function OlMapPage() {
  const [isMobilePanelOpen, setIsMobilePanelOpen] = useState(false);

  const toggleMobilePanel = () => {
    setIsMobilePanelOpen(!isMobilePanelOpen);
  };

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex flex-col md:flex-row flex-1 h-full overflow-hidden">
        <div 
          className={`${isMobilePanelOpen ? 'h-1/2 md:h-auto' : 'h-auto md:h-auto'} 
                     w-full md:w-80 bg-white border-r border-neutral-300 flex flex-col z-10 
                     overflow-hidden transition-all duration-300 md:static 
                     ${isMobilePanelOpen ? 'absolute bottom-0 left-0 right-0' : 'md:relative'}`}
        >
          <SidePanel />
        </div>
        <OlMapContainer 
          toggleMobilePanel={toggleMobilePanel} 
          isMobilePanelOpen={isMobilePanelOpen} 
        />
      </div>
    </div>
  );
}