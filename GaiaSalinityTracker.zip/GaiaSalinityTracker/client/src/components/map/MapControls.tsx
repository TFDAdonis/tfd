import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useMapState } from "@/hooks/useMapState";

const MapControls = () => {
  const { mapState, zoomIn, zoomOut, goToMyLocation, toggleMeasureTool, toggleLayersPanel } = useMapState();

  return (
    <div className="absolute top-4 right-4 flex flex-col space-y-2">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              onClick={zoomIn}
              className="map-control-button w-9 h-9 flex items-center justify-center bg-white shadow-md rounded-md hover:bg-neutral-100 focus:outline-none"
              variant="outline"
              size="icon"
            >
              <span className="material-icons text-neutral-700">add</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Zoom In</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              onClick={zoomOut}
              className="map-control-button w-9 h-9 flex items-center justify-center bg-white shadow-md rounded-md hover:bg-neutral-100 focus:outline-none"
              variant="outline"
              size="icon"
            >
              <span className="material-icons text-neutral-700">remove</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Zoom Out</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              onClick={goToMyLocation}
              className="map-control-button w-9 h-9 flex items-center justify-center bg-white shadow-md rounded-md hover:bg-neutral-100 focus:outline-none"
              variant="outline"
              size="icon"
            >
              <span className="material-icons text-neutral-700">my_location</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>My Location</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              onClick={toggleLayersPanel}
              className="map-control-button w-9 h-9 flex items-center justify-center bg-white shadow-md rounded-md hover:bg-neutral-100 focus:outline-none"
              variant="outline"
              size="icon"
            >
              <span className="material-icons text-neutral-700">layers</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Layers</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              onClick={toggleMeasureTool}
              className="map-control-button w-9 h-9 flex items-center justify-center bg-white shadow-md rounded-md hover:bg-neutral-100 focus:outline-none"
              variant="outline"
              size="icon"
            >
              <span className="material-icons text-neutral-700">straighten</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Measure</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
};

export default MapControls;
